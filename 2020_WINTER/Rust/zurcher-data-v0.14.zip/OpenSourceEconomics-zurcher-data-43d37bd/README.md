# zurcher-data
This repository contains the raw data from Rust (1987) and data reading and processing functions. 

The data and the provided documentation can be found at John Rust's [homepage](https://editorialexpress.com/jrust/nfxp.html).

[![DOI](https://zenodo.org/badge/203568740.svg)](https://zenodo.org/badge/latestdoi/203568740)

